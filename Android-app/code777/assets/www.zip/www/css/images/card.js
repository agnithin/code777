function Card(number, color){
	this.number = number;
	this.color = color;
}