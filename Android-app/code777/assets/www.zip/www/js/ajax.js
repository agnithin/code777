/*$.ajax({
 		type: "GET",
 		async: true,
  		cache: false,
  		url: "http://www.nithinag.com/services/code777/getnewplayer.php",
  		dataType: "json",
  		success: setPlayerId
	});*/


